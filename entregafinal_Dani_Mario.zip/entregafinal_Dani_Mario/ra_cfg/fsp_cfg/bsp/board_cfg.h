/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#ifdef __cplusplus
        extern "C" {
        #endif

void bsp_init(void *p_args);

#ifdef __cplusplus
        }
        #endif
#endif /* BOARD_CFG_H_ */
